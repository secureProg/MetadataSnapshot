const URL = require('url');
const net = require('net');

class UrlValidator {
    constructor() {
        this.blockedProtocols = [
            'file:', 'ftp:', 'javascript:', 'data:', 'gopher:',
            'ldap:', 'ldaps:', 'dict:', 'sftp:', 'http:'
        ];
        
        this.blockedDomains = [
            'localhost', 'localtest', 'internal', 'intranet',
            '127.0.0.1', '0.0.0.0', '::1', '0:0:0:0:0:0:0:1',
            '169.254.169.254',
            '169.254.169.253',
            'metadata.google.internal',
            'metadata', 'instance-data'
        ];

        this.privateIPRanges = [
            /^10\./,
            /^172\.(1[6-9]|2[0-9]|3[01])\./,
            /^192\.168\./,
            /^127\./,
            /^0\./,
            /^169\.254\./,
            /^fc00:/i,
            /^fe80:/i,
            /^::1$/,
            /^::$/
        ];

        this.blockedPorts = [
            22, 23, 25, 53, 110, 143, 993, 995,
            3306, 5432, 6379, 11211, 27017,
            5984, 9200, 9300,
            8080, 8443, 9000, 9090,
            3000, 4000, 5000, 8000, 8888
        ];
    }

    isValidUrl(urlString) {
        try {
            const parsedUrl = new URL.URL(urlString);
            
            if (this.blockedProtocols.includes(parsedUrl.protocol.toLowerCase())) {
                return false;
            }

            const hostname = parsedUrl.hostname.toLowerCase();
            
            if (this.blockedDomains.some(domain => hostname.includes(domain))) {
                return false;
            }

            if (this.isPrivateIP(hostname)) {
                return false;
            }

            const port = parsedUrl.port ? parseInt(parsedUrl.port) : 
                        (parsedUrl.protocol === 'https:' ? 443 : 80);
            if (this.blockedPorts.includes(port)) {
                return false;
            }

            if (this.containsSuspiciousHostname(hostname)) {
                return false;
            }

            if (this.isUrlShortener(hostname)) {
                return false;
            }

            return true;
        } catch (error) {
            return false;
        }
    }

    isPrivateIP(hostname) {
        if (net.isIP(hostname)) {
            return this.privateIPRanges.some(range => range.test(hostname));
        }
        return false;
    }

    containsSuspiciousHostname(hostname) {
        const suspiciousPatterns = [
            /^admin/i, /^api/i, /^internal/i, /^private/i,
            /^test/i, /^dev/i, /^staging/i, /^local/i,
            /\.local$/i, /\.internal$/i, /\.corp$/i,
            /\b(localhost|loopback)\b/i
        ];
        
        return suspiciousPatterns.some(pattern => pattern.test(hostname));
    }

    isUrlShortener(hostname) {
        const shorteners = [
            'bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly',
            'short.link', 'rebrand.ly', 'is.gd', 'v.gd'
        ];
        
        return shorteners.some(shortener => hostname.includes(shortener));
    }

    isValidRedirect(redirectUrl) {
        return this.isValidUrl(redirectUrl);
    }

    extractHostname(urlString) {
        try {
            const parsedUrl = new URL.URL(urlString);
            return parsedUrl.hostname;
        } catch {
            return null;
        }
    }
} 