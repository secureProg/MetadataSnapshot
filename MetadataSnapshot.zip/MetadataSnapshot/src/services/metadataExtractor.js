const axios = require('axios');
const cheerio = require('cheerio');
const UrlValidator = require('./urlValidator');

class MetadataExtractor {
    constructor() {
        this.urlValidator = new UrlValidator();
        
        this.axiosConfig = {
            timeout: 5000,
            maxRedirects: 3,
            validateStatus: null,
            maxContentLength: 50 * 1024 * 1024,
            headers: {
                'User-Agent': 'MetadataSnapshot/1.0 (+https://example.com/bot)'
            }
        };
    }

    async extractMetadata(url) {
        if (!this.urlValidator.isValidUrl(url)) {
            throw new Error('URL validation failed - blocked by security policy');
        }

        try {
            const response = await axios.get(url, {
                ...this.axiosConfig,
                responseType: 'text',
                validateStatus: (status) => status >= 200 && status < 400
            });

            const contentType = response.headers['content-type'] || '';
            if (!contentType.includes('text/html') && !contentType.includes('application/xhtml')) {
                throw new Error('Invalid content type - only HTML content is supported');
            }

            const $ = cheerio.load(response.data);

            const metadata = {
                title: this.sanitizeMetadata($('title').text()),
                description: this.sanitizeMetadata($('meta[name="description"]').attr('content')),
                ogTitle: this.sanitizeMetadata($('meta[property="og:title"]').attr('content')),
                ogDescription: this.sanitizeMetadata($('meta[property="og:description"]').attr('content')),
                ogImage: this.sanitizeMetadata($('meta[property="og:image"]').attr('content')),
                headers: this.filterHeaders(response.headers),
                statusCode: response.status,
                finalUrl: response.request?.res?.responseUrl || url
            };

            return metadata;
        } catch (error) {
            if (error.code === 'ENOTFOUND') {
                throw new Error('Domain not found');
            } else if (error.code === 'ECONNREFUSED') {
                throw new Error('Connection refused');
            } else if (error.code === 'ETIMEDOUT') {
                throw new Error('Request timeout');
            }
            throw new Error(`Failed to fetch metadata: ${error.message}`);
        }
    }

    sanitizeMetadata(value) {
        if (!value) return null;
        return value.trim().substring(0, 500);
    }

    filterHeaders(headers) {
        const safeHeaders = {};
        const allowedHeaders = [
            'content-type', 'content-length', 'last-modified',
            'cache-control', 'expires', 'etag'
        ];
        
        allowedHeaders.forEach(header => {
            if (headers[header]) {
                safeHeaders[header] = headers[header];
            }
        });
        
        return safeHeaders;
    }

    async checkUrlAvailability(url) {
        if (!this.urlValidator.isValidUrl(url)) {
            throw new Error('URL validation failed - blocked by security policy');
        }

        try {
            const response = await axios.head(url, {
                ...this.axiosConfig,
                timeout: 2000,
                maxRedirects: 2
            });
            
            return { 
                available: true, 
                status: response.status,
                finalUrl: response.request?.res?.responseUrl || url
            };
        } catch (error) {
            return { available: false, error: error.message };
        }
    }
} 