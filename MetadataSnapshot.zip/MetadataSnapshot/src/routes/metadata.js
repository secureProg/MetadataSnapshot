const express = require('express');
const { body, query, validationResult } = require('express-validator');
const MetadataExtractor = require('../services/metadataExtractor');

const router = express.Router();
const metadataExtractor = new MetadataExtractor();

const rateLimitMap = new Map();
const RATE_LIMIT_WINDOW = 60000;
const RATE_LIMIT_MAX_REQUESTS = 10;

const rateLimit = (req, res, next) => {
    const clientIP = req.ip || req.connection.remoteAddress;
    const now = Date.now();
    
    if (!rateLimitMap.has(clientIP)) {
        rateLimitMap.set(clientIP, { requests: 1, resetTime: now + RATE_LIMIT_WINDOW });
        return next();
    }
    
    const client = rateLimitMap.get(clientIP);
    
    if (now > client.resetTime) {
        client.requests = 1;
        client.resetTime = now + RATE_LIMIT_WINDOW;
        return next();
    }
    
    if (client.requests >= RATE_LIMIT_MAX_REQUESTS) {
        return res.status(429).json({ error: 'Rate limit exceeded. Try again later.' });
    }
    
    client.requests++;
    next();
};

const validateUrl = [
    body('url')
        .isURL({ protocols: ['https'], require_protocol: true })
        .withMessage('Only HTTPS URLs are allowed')
        .isLength({ max: 2048 })
        .withMessage('URL too long')
        .trim()
        .escape(),
];

router.post('/extract', rateLimit, validateUrl, async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ 
            error: 'Validation failed',
            details: errors.array() 
        });
    }

    try {
        const metadata = await metadataExtractor.extractMetadata(req.body.url);
        
        console.log(`[${new Date().toISOString()}] Metadata extracted for: ${req.body.url}`);
        
        res.json({
            success: true,
            data: metadata,
            extractedAt: new Date().toISOString()
        });
    } catch (error) {
        console.error(`[${new Date().toISOString()}] Error extracting metadata: ${error.message}`);
        res.status(400).json({ 
            error: error.message,
            success: false
        });
    }
});

router.get('/check', rateLimit, [
    query('url')
        .isURL({ protocols: ['https'], require_protocol: true })
        .withMessage('Only HTTPS URLs are allowed')
        .isLength({ max: 2048 })
        .withMessage('URL too long')
        .trim()
        .escape()
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ 
            error: 'Validation failed',
            details: errors.array() 
        });
    }

    const { url } = req.query;

    try {
        const result = await metadataExtractor.checkUrlAvailability(url);
        
        console.log(`[${new Date().toISOString()}] URL availability check for: ${url}`);
        
        res.json({
            success: true,
            data: result,
            checkedAt: new Date().toISOString()
        });
    } catch (error) {
        console.error(`[${new Date().toISOString()}] Error checking URL availability: ${error.message}`);
        res.status(500).json({ 
            error: error.message,
            success: false
        });
    }
});

module.exports = router; 