const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const metadataRoutes = require('./routes/metadata');
const SecurityMiddleware = require('./middleware/security');

const app = express();
const port = process.env.PORT || 3000;

const security = new SecurityMiddleware();

app.set('trust proxy', 1);

app.use(security.securityHeaders);
app.use(security.limitRequestSize(2048));
app.use(security.trackRequest.bind(security));

app.use(cors({
    origin: process.env.ALLOWED_ORIGINS?.split(',') || 'http://localhost:3000',
    credentials: false
}));
app.use(morgan('combined'));
app.use(express.json({ limit: '1mb' }));

// Routes
app.use('/api/metadata', metadataRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        timestamp: new Date().toISOString(),
        service: 'MetadataSnapshot'
    });
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({ error: 'Endpoint not found' });
});

// Error handler
app.use((err, req, res, next) => {
    console.error(`[${new Date().toISOString()}] Error:`, err.stack);
    res.status(500).json({ error: 'Internal server error' });
});

// Cleanup interval for security middleware
setInterval(() => {
    security.cleanup();
}, 60 * 60 * 1000); // Every hour

app.listen(port, () => {
    console.log(`MetadataSnapshot service running on port ${port}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
}); 