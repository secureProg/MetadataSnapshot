/**
 * Additional security middleware for SSRF protection
 * This demonstrates various defensive techniques beyond basic blacklisting
 */

const crypto = require('crypto');

class SecurityMiddleware {
    constructor() {
        // Request tracking for anomaly detection
        this.requestTracking = new Map();
    }

    /**
     * Middleware to add security headers
     */
    securityHeaders(req, res, next) {
        res.setHeader('X-Content-Type-Options', 'nosniff');
        res.setHeader('X-Frame-Options', 'DENY');
        res.setHeader('X-XSS-Protection', '1; mode=block');
        res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
        res.setHeader('Content-Security-Policy', "default-src 'self'");
        next();
    }

    /**
     * Request fingerprinting for anomaly detection
     */
    trackRequest(req, res, next) {
        const clientIP = req.ip || req.connection.remoteAddress;
        const userAgent = req.get('User-Agent') || 'unknown';
        const fingerprint = crypto.createHash('md5')
            .update(clientIP + userAgent)
            .digest('hex');

        if (!this.requestTracking.has(fingerprint)) {
            this.requestTracking.set(fingerprint, {
                requests: 0,
                firstSeen: Date.now(),
                lastSeen: Date.now(),
                urls: new Set()
            });
        }

        const tracking = this.requestTracking.get(fingerprint);
        tracking.requests++;
        tracking.lastSeen = Date.now();
        
        if (req.body && req.body.url) {
            tracking.urls.add(req.body.url);
        }
        if (req.query && req.query.url) {
            tracking.urls.add(req.query.url);
        }

        // Simple anomaly detection
        const timeWindow = 60 * 1000; // 1 minute
        const recentRequests = tracking.requests;
        const uniqueUrls = tracking.urls.size;

        if (recentRequests > 50 || uniqueUrls > 20) {
            console.warn(`[SECURITY] Suspicious activity detected from ${fingerprint}: ${recentRequests} requests, ${uniqueUrls} unique URLs`);
            // In production, this could trigger additional security measures
        }

        next();
    }

    /**
     * Request size limiting middleware
     */
    limitRequestSize(maxSize = 1024) {
        return (req, res, next) => {
            if (req.get('content-length') > maxSize) {
                return res.status(413).json({ error: 'Request too large' });
            }
            next();
        };
    }

    /**
     * Clean up old tracking data
     */
    cleanup() {
        const now = Date.now();
        const maxAge = 24 * 60 * 60 * 1000; // 24 hours

        for (const [key, value] of this.requestTracking.entries()) {
            if (now - value.lastSeen > maxAge) {
                this.requestTracking.delete(key);
            }
        }
    }
}

module.exports = SecurityMiddleware;
